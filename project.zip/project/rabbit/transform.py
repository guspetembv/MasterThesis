import numpy as np


def tof_to_energy(tof, intensity, L0, T0=0.0, E0=0.0):
    
    tof = np.asarray(tof)
    intensity = np.asarray(intensity)

    E = (L0**2) / ((tof - T0)**2) + E0

    jacobian = np.abs((tof - T0)**3 / (2 * L0**2))
    intensity_E = intensity * jacobian
    #intensity_E /= intensity_E.max()
   
    # sort energy ascending
    idx = np.argsort(E)
    
    return E[idx], intensity_E[idx]


def hybrid_rebin_energy(E, Y, E_grid):
    # local spacing of irregular grid
    dE_local = np.gradient(E, edge_order=2)
    
    # convert density to integrated contribution
    weights = Y * dE_local

    # cumulative integral
    cumulative = np.cumsum(weights)

    # ensure zero baseline
    cumulative = cumulative - cumulative[0]

    # interpolate cumulative function
    cumulative_interp = np.interp(
        E_grid,
        E,
        cumulative,
        left=0,
        right=cumulative[-1]
    )

    # differentiate back to density
    Y_uniform = np.gradient(cumulative_interp, E_grid)

    return Y_uniform


def resample_scan_to_energy(scan, L0, T0=0.0, E0=0.0, dE=0.05):
    """
    Convert entire delay scan (delay × ToF)
    to delay × energy on a linear grid.
    """
    dt = 0.001

    tof = scan.tof * dt
    signal = scan.signal

    # convert first spectrum to determine energy range
    E, Y = tof_to_energy(tof, signal[0], L0, T0, E0)
    
    E_grid = np.arange(E.min(), E.max(), dE)

    signal_E = np.zeros((signal.shape[0], len(E_grid)))

    for i in range(signal.shape[0]):

        E, Y = tof_to_energy(tof, signal[i], L0, T0, E0)

        Y_uniform = hybrid_rebin_energy(E, Y, E_grid)

        signal_E[i] = Y_uniform

    signal_E /= signal_E.max()

    return E_grid, signal_E
