
import numpy as np

def integrate_energy_range(energy, signal, e_min, e_max):
    mask = (energy >= e_min) & (energy <= e_max)
    return signal[:, mask].mean(axis=1)

