import numpy as np

from .sidebands import integrate_energy_range
from .fft_analysis import fourier_transform, dominant_frequency_fwhm
from .fitting import fit_sideband, cosine


def analyze_sidebands(energy, signal_E, delays, sidebands):
    """
    Integrates sidebands, extracts omega via FFT,
    computes averaged omega, and performs curve fitting.
    """

    sb_results = {}
    omega_values = []
    fwhm_values = []

    # -------- integrate sidebands + FFT --------
    for name, (emin, emax) in sidebands.items():

        sb_signal = integrate_energy_range(
            energy,
            signal_E,
            emin,
            emax
        )

        fft_sb, freqs = fourier_transform(sb_signal, delays, n=2000)

        freq_sb, fwhm = dominant_frequency_fwhm(freqs, fft_sb)
        omega_sb = 2*np.pi*freq_sb
        print(omega_sb)
        
        omega_values.append(omega_sb)
        fwhm_values.append(fwhm)

        sb_results[name] = {
            "energy_range": (emin, emax),
            "signal": sb_signal,
            "omega_fft": omega_sb,
            "fwhm": fwhm
        }

    # -------- weighted omega average --------
    weights = 1 / np.array(fwhm_values)
    omega_avg = np.average(omega_values, weights=weights)

    # -------- curve fitting --------
    for name in sb_results:

        signal = sb_results[name]["signal"]

        params, errs = fit_sideband(
            delays,
            signal,
            omega_avg
        )

        fit_curve = cosine(
            delays,
            params[0],
            omega_avg,
            params[1],
            params[2]
        )

        sb_results[name]["params"] = params
        sb_results[name]["errors"] = errs
        sb_results[name]["fit_curve"] = fit_curve

    return sb_results, omega_avg
