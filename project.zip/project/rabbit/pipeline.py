

from .config import load_config
from .scan import load_scan
from .calibration import fit_calibration
from .fft_analysis import fourier_transform, dominant_frequency_fwhm
from .fitting import fit_sideband, cosine
from .transform import resample_scan_to_energy
from .plotting.spectra import mean_spectrum, energy_spectrum, plot_all_sideband_fits
from .plotting.scans import tof_delay_map, energy_delay_map, curve_fit_plot, fft_map
from .sidebands import integrate_energy_range
from .plotting import config_figures
from .sideband_analysis import analyze_sidebands

import numpy as np

def run_pipeline(config_path):

    cfg = load_config(config_path)

    scan = load_scan(cfg["data_file"], cfg["delay_factor"])

    print("Scan shape:", scan.signal.shape)

    mean_spectrum(scan)
    tof_delay_map(scan)

    harmonics = cfg["harmonics"]
    harmonic_tofs = cfg["harmonic_tofs"]

    L,T0,E0 = fit_calibration(
        harmonics,
        harmonic_tofs,
        cfg["omega"],
        cfg["gas"]
    )

    print("Calibration parameters: L=",L,", T0=",T0,", E0=",E0)
    
    energy, signal_E = resample_scan_to_energy(
        scan,
        L,
        T0,
        E0,
        dE=0.001
    )

    energy_spectrum(energy, signal_E, xlim=(0,45))
    
    energy_delay_map(energy, scan.delays, signal_E, ylim=(0,45))

    sidebands = cfg["sidebands"]
    sb_results, omega_avg = analyze_sidebands(
        energy,
        signal_E,
        scan.delays,
        sidebands
    )

    print("Average omega:", omega_avg)
    
    plot_all_sideband_fits(scan.delays, sb_results)

   
