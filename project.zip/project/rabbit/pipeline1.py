
from .config import load_config
from .scan import load_scan
from .calibration import fit_calibration
from .fft_analysis import fourier_transform, dominant_frequency_fwhm
from .fitting import fit_sideband, cosine
from .transform import resample_scan_to_energy
from .plotting.spectra import mean_spectrum, energy_spectrum, plot_all_sideband_fits
from .plotting.scans import tof_delay_map, energy_delay_map, curve_fit_plot, fft_map
from .sidebands import integrate_energy_range
from .plotting import config_figures

import numpy as np

def run_pipeline(config_path):

    cfg = load_config(config_path)

    scan = load_scan(cfg["data_file"], cfg["delay_factor"])

    print("Scan shape:", scan.signal.shape)

    mean_spectrum(scan)
    tof_delay_map(scan)

    harmonics = cfg["harmonics"]
    harmonic_tofs = cfg["harmonic_tofs"]

    L,T0,E0 = fit_calibration(
        harmonics,
        harmonic_tofs,
        cfg["omega"],
        cfg["gas"]
    )

    print("Calibration parameters: L=",L,", T0=",T0,", E0=",E0)
    
    energy, signal_E = resample_scan_to_energy(
        scan,
        L,
        T0,
        E0,
        dE=0.001
    )

    energy_spectrum(energy, signal_E, xlim=(0,45))
    
    energy_delay_map(energy, scan.delays, signal_E, ylim=(0,45))

    sidebands = cfg["sidebands"]

    sb_results = {}
    omega_values = []

    for name, (emin, emax) in sidebands.items():

        sb_signal = integrate_energy_range(
            energy,
            signal_E,
            emin,
            emax
        )

        fft_sb, freqs = fourier_transform(sb_signal, scan.delays, n=2000)

        freq_sb, fwhm = dominant_frequency_fwhm(freqs, fft_sb)
        omega_sb = 2*np.pi*freq_sb
        print(omega_sb)
        omega_values.append(omega_sb)

        sb_results[name] = {
            "energy_range": (emin, emax),
            "signal": sb_signal,
            "omega_fft": omega_sb,
            "fwhm": fwhm
        }

    #omega_avg = np.mean(omega_values)
    #omega_avg = 3.8434777506283755
    weights = 1 / np.array([sb_results[k]["fwhm"] for k in sb_results])
    omega_avg = np.average(omega_values, weights=weights)
    print("Average omega from sidebands:", omega_avg)
     
    #fft, freqs = fourier_transform(signal_E, scan.delays, n=500)
    #fft_map(energy, freqs, fft, ylim=(0,25))

    for name in sb_results:

        sb_signal = sb_results[name]["signal"]

        params, errs = fit_sideband(
            scan.delays,
            sb_signal,
            omega_avg
        )
        print(name,"phase",params[2])
        fit_curve = cosine(
            scan.delays,
            params[0],
            omega_avg,
            params[1],
            params[-1]
        )

        sb_results[name]["params"] = params
        sb_results[name]["errors"] = errs
        sb_results[name]["fit_curve"] = fit_curve

    plot_all_sideband_fits(scan.delays, sb_results)

    """
    #sidebands = cfg["sidebands"]

    SB_signal = integrate_energy_range(energy, signal_E, 16.8, 18.1)

    params, errs = fit_sideband(scan.delays, SB_signal, 3.8)
    
    fit_curve = cosine(scan.delays, params[1], 3.8, params[2], params[-1])
    
    curve_fit_plot(scan.delays, fit_curve, SB_signal)

    fft, freqs = fourier_transform(signal_E, scan.delays)

    fft_map(energy, freqs, fft, ylim=(0,45))
    """
