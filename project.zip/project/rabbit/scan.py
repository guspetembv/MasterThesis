
import pandas as pd
import numpy as np

class RabbitScan:
    def __init__(self, tof, delays, signal):
        self.tof = tof
        self.delays = delays
        self.signal = signal

def load_scan(path, factor):
    df = pd.read_csv(path, sep=",", header=None)
    df.columns = ["tof","signal","stage"]

    groups = df.groupby("stage")

    delays = []
    spectra = []

    for stage, g in groups:
        delays.append(stage)
        spectra.append(g["signal"].values)

    delays = np.array(delays) * factor
    delays -= delays.min()
    spectra = np.array(spectra)
    tof = g["tof"].values

    return RabbitScan(tof, delays, spectra)
