
import numpy as np
from scipy.optimize import curve_fit

h = 4.135667696e-15 #eV*s
c = 299792458 #m/s

BINDING_ENERGIES = {
    "Ne": 21.564,
    "Ar": 15.759,
    "Kr": 14.000,
    "Xe": 12.130,
}
#Eb = 15.759 #eV


def tof_model(q, L, T0, E0, w, Eb):
    return np.sqrt((L**2)/(2*(q*h*c/w-Eb-E0))) + T0

def fit_calibration(harmonics, tof_positions, omega, gas):
    Eb = BINDING_ENERGIES[gas]
    popt,_ = curve_fit(
        lambda q,L,T0,E0: tof_model(q,L,T0,E0,omega,Eb),
        harmonics,
        tof_positions
    )
    return popt
