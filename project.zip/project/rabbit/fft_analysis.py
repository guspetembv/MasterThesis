
import numpy as np

def fourier_transform(signal, delays, n):

    delays = delays - delays.min()
    dt = np.mean(np.diff(delays))

    signal -= signal.mean(axis=0)
    fft = np.abs(np.fft.fftshift(np.fft.fft(signal, n=n, axis=0), axes=0))
    freqs = np.fft.fftshift(np.fft.fftfreq(n, dt))

    return fft, freqs


def dominant_frequency_fwhm1(freqs, spectrum):

    mag = np.abs(spectrum)

    idx = np.argmax(mag)

    peak_freq = freqs[idx]

    half_max = mag[idx] / 2

    left = idx
    while left > 0 and mag[left] > half_max:
        left -= 1

    right = idx
    while right < len(mag)-1 and mag[right] > half_max:
        right += 1

    fwhm = freqs[right] - freqs[left]

    return peak_freq, fwhm


def dominant_frequency_fwhm(freqs, spectrum):

    spectrum = np.abs(spectrum)

    mask = freqs > 0
    freqs = freqs[mask]
    spectrum = spectrum[mask]

    idx = np.argmax(spectrum)

    peak_freq = freqs[idx]

    half_max = spectrum[idx] / 2

    left = idx
    while left > 0 and spectrum[left] > half_max:
        left -= 1

    right = idx
    while right < len(spectrum)-1 and spectrum[right] > half_max:
        right += 1

    fwhm = freqs[right] - freqs[left]

    return peak_freq, fwhm
