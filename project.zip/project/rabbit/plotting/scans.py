
import matplotlib.pyplot as plt

cmap = "jet"

def tof_delay_map(scan):
    plt.figure(figsize=(8,6))
    plt.imshow(
        scan.signal.T,
        aspect="auto",
        origin="lower",
        extent=[scan.delays.min(), scan.delays.max(),
                scan.tof.min(), scan.tof.max()],
        cmap=cmap
    )

    plt.ylabel("ToF")
    plt.xlabel("Delay")
    plt.title("Delay vs ToF Map")
    plt.colorbar(label="Signal")
    plt.show()

def energy_delay_map(energy, delays, signal, ylim):
    plt.figure(figsize=(8,6))
    plt.imshow(
        signal.T,
        aspect="auto",
        origin="lower",
        extent=[delays.min(), delays.max(),
                energy.min(), energy.max()],
        cmap=cmap

    )

    if ylim is not None:
        plt.ylim(*ylim)
    plt.ylabel("Energy (eV)")
    plt.xlabel("Delay")
    plt.title("Delay vs Energy Map")
    plt.colorbar(label="Signal")
    plt.show()

def fft_map(energy, freqs, fft_signal, ylim):
    plt.figure(figsize=(8,6))
    plt.imshow(
        fft_signal.T,
        aspect="auto",
        origin="lower",
        extent=[freqs.min(), freqs.max(),
                energy.min(), energy.max()],
        cmap=cmap

    )

    if ylim is not None:
        plt.ylim(*ylim)

    plt.ylabel("Energy (eV)")
    plt.xlabel("Frequency (1/fs)")
    plt.title("FFT RABBIT scan")
    plt.xlim(0,1.5)
    plt.colorbar(label="Signal")
    plt.show()

def curve_fit_plot(delay, fit_curve, SB_signal):
    plt.plot(delay, fit_curve)
    plt.scatter(delay, SB_signal)
    plt.show()
