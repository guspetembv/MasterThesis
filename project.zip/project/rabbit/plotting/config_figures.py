import matplotlib
matplotlib.rcParams["mathtext.fontset"] = "cm"     # Computer Modern
matplotlib.rcParams["font.family"] = "serif"
import matplotlib.pyplot as plt

plt.rcParams.update({
    "font.family": "serif",
    "font.size": 13,
    "axes.labelsize": 14,
    "axes.titlesize": 15,
    "legend.fontsize": 12,
    "xtick.labelsize": 12,
    "ytick.labelsize": 12,
    "axes.linewidth": 1.2,
    "lines.linewidth": 2.2,
    "figure.dpi": 120
})


