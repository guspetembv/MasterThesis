
import matplotlib.pyplot as plt

def mean_spectrum(scan):

    mean_spec = scan.signal.mean(axis=0)

    plt.figure(figsize=(10,5))
    plt.plot(scan.tof, mean_spec)

    plt.xlabel("ToF")
    plt.ylabel("Signal")
    plt.title("Mean ToF Spectrum")

    plt.show()


def energy_spectrum(energy, signal, xlim=None):

    mean_spec = signal.mean(axis=0)

    plt.figure(figsize=(10,5))
    plt.plot(energy, mean_spec)
    
    if xlim is not None:
        plt.xlim(*xlim)
    plt.xlabel("Energy (eV)")
    plt.ylabel("Signal")
    plt.title("Mean Energy Spectrum")

    plt.show()


def plot_all_sideband_fits(delays, sb_results):

    plt.figure(figsize=(8,6))

    for name, sb in sb_results.items():

        signal = sb["signal"]
        fit = sb["fit_curve"]

        line = plt.plot(delays, signal, "o", label=f"{name} data")[0]
        color = line.get_color()
        plt.plot(delays, fit, "-", color=color, label=f"{name} fit")

    plt.xlabel("Delay")
    plt.ylabel("Sideband intensity")
    plt.legend()
    plt.tight_layout()

    plt.show()
