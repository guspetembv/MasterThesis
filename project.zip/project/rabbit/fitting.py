
import numpy as np
from scipy.optimize import curve_fit

def cosine(t, A, w, phi, c):
    return A * np.cos(w*t + phi) + c

def fit_sideband(delay, signal, w):
    popt, pcov = curve_fit(
        lambda t,A,phi,c: cosine(t,A,w,phi,c),
        delay,
        signal
    )
    return popt, pcov
