
from rabbit.pipeline import run_pipeline
import sys

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python run_pipeline.py config.yaml")
        sys.exit(1)
    run_pipeline(sys.argv[1])
