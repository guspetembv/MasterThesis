
# RABBIT Analysis Pipeline v2

A modular analysis framework for attosecond RABBIT experiments.

## Features
- Scan reconstruction (delay × ToF matrix)
- Diagnostic plots
- Manual harmonic calibration
- ToF → Energy transformation
- FFT diagnostic

## Install
pip install numpy scipy pandas matplotlib pyyaml

## Run
python run_pipeline.py config.yaml
